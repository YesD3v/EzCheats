/*  ═══════════════════════════════════════════════════════
    EzForms — Content Script  v1.1
    Google Forms Locked-Mode Unlocker · stealth UI
    Based on xNasuni/google-forms-unlocker
    ═══════════════════════════════════════════════════════ */

(function () {
  'use strict';

  // ── Guard: only run on actual Google Forms quiz/form pages ──
  const url = location.href;
  const isFormPage = /\/forms\/d\/(e\/)?[A-Za-z0-9_-]+\/(viewform|formResponse)/i.test(url);
  if (!isFormPage) return;

  // Don't double-inject
  if (document.getElementById('ezforms-toast')) return;

  // ─── State ─────────────────────────────────────────
  let isUnlocked = false;
  let unlockerInterval = null;
  let originalAddEventListener = null;

  const BLOCKED_EVENTS = [
    'mozvisibilitychange',
    'webkitvisibilitychange',
    'msvisibilitychange',
    'visibilitychange',
    'pagehide'
  ];

  const ASSESSMENT_EXT_ID = 'gndmhdcefbhlchkhipcnnbkcmicncehk';

  // ─── SVG fragments ────────────────────────────────
  const SVG_UNLOCK = `<svg viewBox="0 0 24 24"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 9.9-1"/></svg>`;
  const SVG_LOCK   = `<svg viewBox="0 0 24 24"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>`;

  const SVG_UNLOCK_SM = `<svg class="ezforms-toast-icon" viewBox="0 0 24 24"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 9.9-1"/></svg>`;
  const SVG_LOCK_SM   = `<svg class="ezforms-toast-icon" viewBox="0 0 24 24"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>`;

  // ─── Build UI ──────────────────────────────────────

  // Toast
  const toast = document.createElement('div');
  toast.id = 'ezforms-toast';
  toast.className = 'locked';
  toast.innerHTML = `<div class="ezforms-toast-inner"><span class="ezforms-dot"></span>${SVG_LOCK_SM}<span>Locked</span></div>`;

  // Unlock zone (visible when locked — click to unlock)
  const unlockZone = document.createElement('div');
  unlockZone.id = 'ezforms-unlock-zone';
  unlockZone.innerHTML = `<div class="ezforms-reveal"><div class="ezforms-btn">${SVG_UNLOCK}</div></div>`;

  // Lock zone (visible when unlocked — click to re-lock)
  const lockZone = document.createElement('div');
  lockZone.id = 'ezforms-lock-zone';
  lockZone.innerHTML = `<div class="ezforms-reveal"><div class="ezforms-btn">${SVG_LOCK}</div></div>`;

  // ─── Inject DOM ───────────────────────────────────
  function injectUI() {
    const root = document.body || document.documentElement;
    root.appendChild(toast);
    root.appendChild(unlockZone);
    root.appendChild(lockZone);
  }
  if (document.body) injectUI();
  else document.addEventListener('DOMContentLoaded', injectUI);

  // ─── Toast ────────────────────────────────────────
  let toastTimer = null;
  function showToast(text, type) {
    if (toastTimer) clearTimeout(toastTimer);
    toast.classList.remove('show', 'unlocked', 'locked');
    toast.className = type;
    toast.innerHTML = `<div class="ezforms-toast-inner"><span class="ezforms-dot"></span>${type === 'unlocked' ? SVG_UNLOCK_SM : SVG_LOCK_SM}<span>${text}</span></div>`;

    // Force reflow then animate in
    void toast.offsetWidth;
    toast.classList.add('show');

    toastTimer = setTimeout(() => toast.classList.remove('show'), 2000);
  }

  // ─── Page-world script (runs in MAIN world) ──────
  function injectPageScript() {
    const s = document.createElement('script');
    s.textContent = `(function(){
      'use strict';
      var AID='gndmhdcefbhlchkhipcnnbkcmicncehk';
      var BLK=['mozvisibilitychange','webkitvisibilitychange','msvisibilitychange','visibilitychange','pagehide'];
      var active=false;
      var origSend=null;
      var origAdd=document.addEventListener.bind(document);

      window.addEventListener('message',function(e){
        if(e.data&&e.data.type==='EZFORMS_TOGGLE'){
          active=e.data.active;
          if(active&&window.chrome&&window.chrome.runtime&&window.chrome.runtime.sendMessage&&!origSend){
            origSend=window.chrome.runtime.sendMessage.bind(window.chrome.runtime);
          }
        }
      });

      setInterval(function(){
        if(!active)return;
        try{
          if(window.chrome&&window.chrome.runtime){
            window.chrome.runtime.sendMessage=function(){
              var id=arguments[0],pl=arguments[1],cb=arguments[2];
              if(id===AID&&pl&&cb){
                if(pl.command==='isLocked'){cb({locked:true});return null;}
                if(pl.command==='lock'){cb({locked:true});return null;}
                if(pl.command==='unlock'){cb({locked:false});return null;}
              }
              if(origSend)return origSend.apply(window.chrome.runtime,arguments);
            };
          }
          var vp=[['hidden',false],['visibilityState','visible'],['webkitVisibilityState','visible'],['mozVisibilityState','visible'],['msVisibilityState','visible']];
          vp.forEach(function(p){try{Object.defineProperty(document,p[0],{value:p[1],writable:false,configurable:true});}catch(e){}});
          document.addEventListener=function(){
            if(BLK.indexOf(arguments[0])!==-1)return;
            return origAdd.apply(document,arguments);
          };
        }catch(e){}
      },50);
    })();`;
    (document.head || document.documentElement).appendChild(s);
    s.remove();
  }
  injectPageScript();

  // ─── Core unlocker (content-script world) ─────────
  function startUnlocker() {
    if (unlockerInterval) return;

    if (!originalAddEventListener) {
      originalAddEventListener = document.addEventListener.bind(document);
    }

    unlockerInterval = setInterval(() => {
      try {
        // Visibility patches
        [['hidden', false], ['visibilityState', 'visible'], ['webkitVisibilityState', 'visible'],
         ['mozVisibilityState', 'visible'], ['msVisibilityState', 'visible']].forEach(([p, v]) => {
          try { Object.defineProperty(document, p, { value: v, writable: false, configurable: true }); } catch (e) {}
        });

        // Block visibility event listeners
        document.addEventListener = function () {
          if (BLOCKED_EVENTS.indexOf(arguments[0]) !== -1) return;
          return originalAddEventListener.apply(document, arguments);
        };
      } catch (e) {}
    }, 50);

    // Tell page-world script
    window.postMessage({ type: 'EZFORMS_TOGGLE', active: true }, '*');
  }

  function stopUnlocker() {
    if (unlockerInterval) {
      clearInterval(unlockerInterval);
      unlockerInterval = null;
    }
    if (originalAddEventListener) {
      document.addEventListener = originalAddEventListener;
    }
    window.postMessage({ type: 'EZFORMS_TOGGLE', active: false }, '*');
  }

  // ─── Toggle ───────────────────────────────────────
  function unlock() {
    isUnlocked = true;
    startUnlocker();
    showToast('Unlocked', 'unlocked');
    unlockZone.style.display = 'none';
    lockZone.style.display = 'block';
  }

  function lock() {
    isUnlocked = false;
    stopUnlocker();
    showToast('Locked', 'locked');
    lockZone.style.display = 'none';
    unlockZone.style.display = 'block';
  }

  // ─── Events ───────────────────────────────────────
  unlockZone.addEventListener('click', (e) => { e.stopPropagation(); e.preventDefault(); unlock(); });
  lockZone.addEventListener('click',   (e) => { e.stopPropagation(); e.preventDefault(); lock(); });

  console.log('%c[EzForms]%c Ready — hover top-right corner', 'color:#fff;font-weight:bold;', 'color:#666;');
})();
