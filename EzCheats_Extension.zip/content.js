(function() {
    if (document.getElementById('ezcheats-container')) return;

    const container = document.createElement('div');
    container.id = 'ezcheats-container';
    container.style.display = 'none'; 
    container.innerHTML = `
      <div id="ezcheats-loading">
          <div class="ezcheats-spinner"></div>
          <div style="font-weight: 600; color: #ccc;">Loading Assets...</div>
      </div>
      
      <!-- API Manager List View -->
      <div id="ezcheats-settings" style="display: none;">
          <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 5px;">
              <h2 style="margin: 0; color: white;">API Manager</h2>
              <button id="ezcheats-close-settings" class="ezcheats-icon-btn">&times;</button>
          </div>
          <p style="color: #aaa; font-size: 13px; text-align: left; margin: 0 0 10px 0;">Select an API or create a new one.</p>
          <div id="ezcheats-api-list"></div>
          <button id="ezcheats-add-api-btn" title="Add API">+</button>
      </div>

      <!-- API Manager Edit View -->
      <div id="ezcheats-api-edit-view" style="display: none; flex-direction: column; position: absolute; inset: 0; background: rgba(15, 15, 20, 0.98); z-index: 101; padding: 30px; box-sizing: border-box;">
          <h2 style="margin: 0 0 20px 0; color: white; text-align: left;" id="ezcheats-edit-title">Edit API</h2>
          <input type="hidden" id="ezcheats-edit-id">
          
          <label style="color: #aaa; font-size: 12px; text-align: left; margin-bottom: 5px;">Name</label>
          <input type="text" id="ezcheats-edit-name" placeholder="My API" class="ezcheats-input-field" style="margin-bottom: 15px;" autocomplete="off">
          
          <label style="color: #aaa; font-size: 12px; text-align: left; margin-bottom: 5px;">API Key</label>
          <input type="text" id="ezcheats-edit-key" placeholder="..." class="ezcheats-input-field" style="margin-bottom: 25px;" autocomplete="off">
          
          <div style="display: flex; gap: 10px; margin-bottom: 10px;">
              <button id="ezcheats-save-api-btn" style="flex: 1; background: #0a84ff; border: none; padding: 12px; border-radius: 12px; color: white; font-weight: 600; cursor: pointer;">Save</button>
              <button id="ezcheats-delete-api-btn" style="flex: 1; background: rgba(255, 69, 58, 0.2); border: 1px solid rgba(255, 69, 58, 0.5); padding: 12px; border-radius: 12px; color: #ff453a; font-weight: 600; cursor: pointer;">Delete</button>
          </div>
          <button id="ezcheats-cancel-api-btn" style="background: transparent; border: 1px solid rgba(255,255,255,0.2); padding: 12px; border-radius: 12px; color: white; cursor: pointer; transition: all 0.2s;">Cancel</button>
      </div>

      <div id="ezcheats-header">
        <div style="width: 80px; text-align: left; display: flex; align-items: center; gap: 10px;">
            <button id="ezcheats-clear" class="ezcheats-icon-btn" title="New Chat">&#8635;</button>
        </div>
        <div id="ezcheats-drag-bar"></div>
        <div style="width: 80px; text-align: right; display: flex; justify-content: flex-end; align-items: center; gap: 8px;">
            <button id="ezcheats-settings-btn" class="ezcheats-icon-btn" title="API Manager">&#9881;</button>
            <button id="ezcheats-close" class="ezcheats-icon-btn" title="Hide">&times;</button>
        </div>
      </div>
      <div id="ezcheats-chat-area"></div>
      <div id="ezcheats-input-area">
        <input type="text" id="ezcheats-input" placeholder="Message AI Chat..." autocomplete="off">
        <button id="ezcheats-send" title="Send">&#10148;</button>
      </div>
    `;
    
    if (document.body) {
        document.body.appendChild(container);
    } else {
        document.addEventListener('DOMContentLoaded', () => document.body.appendChild(container));
    }

    const header = document.getElementById('ezcheats-header');
    const chatArea = document.getElementById('ezcheats-chat-area');
    const input = document.getElementById('ezcheats-input');
    const sendBtn = document.getElementById('ezcheats-send');
    const closeBtn = document.getElementById('ezcheats-close');
    const clearBtn = document.getElementById('ezcheats-clear');
    const settingsBtn = document.getElementById('ezcheats-settings-btn');
    const loadingScreen = document.getElementById('ezcheats-loading');
    const settingsScreen = document.getElementById('ezcheats-settings');

    function showErrorToast(message) {
        let toast = document.getElementById('ezcheats-error-toast');
        if (!toast) {
            toast = document.createElement('div');
            toast.id = 'ezcheats-error-toast';
            toast.className = 'ezcheats-toast';
            if (document.getElementById('ezcheats-container')) {
                document.getElementById('ezcheats-container').appendChild(toast);
            } else {
                document.body.appendChild(toast);
            }
        }
        toast.innerHTML = `<span style="font-size:18px;">&#9888;&#65039;</span> <span>${message}</span>`;
        toast.offsetHeight; 
        toast.classList.add('show');
        setTimeout(() => toast.classList.remove('show'), 4500);
    }

    function shuffleNodeInstance(btn = null) {
        if (btn) {
            btn.innerText = "Shuffling...";
            btn.style.transform = "scale(0.95)";
        }
        
        chrome.runtime.sendMessage({ action: 'fetchKeys' }, (response) => {
            if (response && response.error) {
                showErrorToast(response.error);
                if (btn) {
                    btn.innerText = "Shuffle Failed!";
                    btn.style.borderColor = "rgba(255, 69, 58, 0.8)";
                    btn.style.color = "#ff453a";
                    btn.style.transform = "scale(1)";
                    setTimeout(() => {
                        btn.innerText = "Shuffle Node Instance";
                        btn.style.borderColor = "";
                        btn.style.color = "";
                    }, 3000);
                }
                return;
            }
            
            if (response && response.keys && response.keys.length > 0) {
                const keys = response.keys;
                let randomKey = keys[Math.floor(Math.random() * keys.length)].trim();
                try {
                    let finalKey = decodeURIComponent(escape(atob(randomKey)));
                    chrome.storage.local.set({ ezcheats_active_key: finalKey });
                    
                    if (btn) {
                        btn.innerText = "Node Shuffled!";
                        btn.style.transform = "scale(1)";
                        btn.style.borderColor = "#fff";
                        
                        setTimeout(() => {
                            btn.innerText = "Shuffle Node Instance";
                            btn.style.borderColor = "";
                        }, 2000);
                    }
                } catch (decodeErr) {
                    showErrorToast("Decoding Error: Make sure Pastebin is strictly Base64 UTF-8.");
                }
            } else {
                showErrorToast("No API keys found on Pastebin (Contact Owner)");
            }
        });
    }

    function initSettingsUI() {
        const settingsDiv = document.getElementById('ezcheats-settings');
        settingsDiv.innerHTML = `
            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom: 20px;">
                <h3 style="margin:0; font-weight:600; font-size:16px;">System Configuration</h3>
                <button id="ezcheats-close-settings" class="ezcheats-icon-btn" title="Close Settings">&times;</button>
            </div>
            
            <div style="flex:1; display:flex; flex-direction:column; align-items:center; justify-content:center; gap: 20px; text-align: center;">
                <div style="width: 50px; height: 50px; margin: 0 auto; fill: none; stroke: white; stroke-width: 2; stroke-linecap: round; stroke-linejoin: round;">
                    <svg viewBox="0 0 24 24">
                        <polyline points="16 3 21 3 21 8"></polyline>
                        <line x1="4" y1="20" x2="21" y2="3"></line>
                        <polyline points="21 16 21 21 16 21"></polyline>
                        <line x1="15" y1="15" x2="21" y2="21"></line>
                        <line x1="4" y1="4" x2="9" y2="9"></line>
                    </svg>
                </div>
                <div>
                    <div style="font-weight: 600; font-size: 18px; margin-bottom: 5px;">Native Node Active</div>
                    <div style="font-size: 13px; color: #aaa;">Your connection is routed through securely embedded native AI nodes.</div>
                </div>
                <button id="ezcheats-gamble-btn" style="margin-top:10px;">Shuffle Node Instance</button>
            </div>
        `;

        document.getElementById('ezcheats-close-settings').addEventListener('click', () => {
            settingsDiv.style.display = 'none';
        });

        document.getElementById('ezcheats-gamble-btn').addEventListener('click', (e) => {
            shuffleNodeInstance(e.target);
        });
    }

    settingsBtn.addEventListener('click', () => {
        document.getElementById('ezcheats-settings').style.display = 'flex';
    });

    initSettingsUI();

    chrome.storage.local.get(['ezcheats_active_key'], (res) => {
        if (!res.ezcheats_active_key) {
            chrome.runtime.sendMessage({ action: 'fetchKeys' }, (response) => {
                if (response && response.error) {
                    showErrorToast(response.error);
                    return;
                }
                if (response && response.keys && response.keys.length > 0) {
                    const keys = response.keys;
                    let randomKey = keys[Math.floor(Math.random() * keys.length)].trim();
                    try {
                        let finalKey = decodeURIComponent(escape(atob(randomKey)));
                        chrome.storage.local.set({ ezcheats_active_key: finalKey });
                    } catch (e) {
                        showErrorToast("Decoding Error on Startup");
                    }
                } else {
                    showErrorToast("No API keys found on Pastebin (Contact Owner)");
                }
            });
        }
    });

    chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
        if (msg.action === 'toggleUI') {
            sendResponse({ status: "ok" }); 
            if (container.style.display === 'none' || container.style.display === '') {
                container.style.display = 'flex';
                loadingScreen.style.opacity = '1';
                loadingScreen.style.display = 'flex';
                
                // Automatically shuffle the node instance when UI opens
                shuffleNodeInstance();
                
                setTimeout(() => {
                    loadingScreen.style.opacity = '0';
                    setTimeout(() => { loadingScreen.style.display = 'none'; }, 400);
                }, 800);
            } else {
                container.style.display = 'none';
            }
        }
        return true;
    });

    let isDragging = false;
    let startX, startY, initialX, initialY;

    header.addEventListener('mousedown', (e) => {
        if (e.target.id !== 'ezcheats-drag-bar') return;
        
        isDragging = true;
        startX = e.clientX;
        startY = e.clientY;
        const rect = container.getBoundingClientRect();
        initialX = rect.left;
        initialY = rect.top;
        
        container.style.left = initialX + 'px';
        container.style.top = initialY + 'px';
        container.style.right = 'auto';
        container.style.bottom = 'auto';
    });

    document.addEventListener('mousemove', (e) => {
        if (!isDragging) return;
        let newX = initialX + (e.clientX - startX);
        let newY = initialY + (e.clientY - startY);
        
        const maxX = window.innerWidth - container.offsetWidth;
        const maxY = window.innerHeight - container.offsetHeight;
        
        newX = Math.max(0, Math.min(newX, maxX));
        newY = Math.max(0, Math.min(newY, maxY));
        
        container.style.left = newX + 'px';
        container.style.top = newY + 'px';
    });

    document.addEventListener('mouseup', () => { isDragging = false; });
    closeBtn.addEventListener('click', () => { container.style.display = 'none'; });

    const SYSTEM_PROMPT = `You are EzCheats, an advanced AI.
CRITICAL INSTRUCTIONS:
1. You will receive 'PAGE CONTEXT' (visible text and form fields).
2. IGNORE the form UNLESS the user explicitly asks you to "fill", "solve", or "answer" it. If they say "hi" or ask a general question, ONLY reply normally.
3. If asked to fill the form, evaluate the correct answers based on the options, and output a JSON block to command the UI.
4. For radio/checkbox options, output {"id": "exact_field_id", "value": true}.
5. Do NOT output internal Field IDs or Markdown tables of your answers to the user. Use bold text to summarize your answers nicely.
6. When you fill out a form, provide a short, friendly confirmation message directly in your response, matching the language of the user's prompt.
7. Do NOT output <think> blocks, internal monologues, or reasoning traces. Provide your final answer directly to save tokens.

JSON FORMAT (ONLY IF FILLING FORM):
\`\`\`json
{
  "fill": [
    {"id": "exact_field_id", "value": "text answer OR true"}
  ]
}
\`\`\``;

    let chatHistory = [];
    
    function parseMarkdown(text) {
        let html = text.replace(/</g, '&lt;').replace(/>/g, '&gt;');
        html = html.replace(/```([\s\S]*?)```/g, '<pre style="background:rgba(0,0,0,0.2);padding:10px;border-radius:8px;overflow-x:auto;margin:5px 0;font-family:monospace;font-size:13px;"><code>$1</code></pre>');
        html = html.replace(/`([^`]+)`/g, '<code style="background:rgba(0,0,0,0.2);padding:2px 5px;border-radius:4px;font-family:monospace;font-size:13px;">$1</code>');
        html = html.replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>');
        html = html.replace(/\*([^*]+)\*/g, '<em>$1</em>');
        html = html.replace(/\[([^\]]+)\]\(([^)]+)\)/g, '<a href="$2" target="_blank" style="color:#0a84ff;text-decoration:underline;">$1</a>');
        html = html.replace(/\n/g, '<br>');
        return html;
    }



    function addMessage(text, sender) {
        if (sender === 'ai') {
            text = text.replace(/<think>[\s\S]*?<\/think>/g, '');
            text = text.replace(/```json[\s\S]*?```/g, '');
        }
        
        text = text.trim();
        if (!text && sender === 'ai') text = '<span style="opacity:0.5;font-style:italic;">Operating UI...</span>';
        
        const msgDiv = document.createElement('div');
        msgDiv.className = 'ezcheats-msg ' + sender;
        msgDiv.innerHTML = parseMarkdown(text);
        chatArea.appendChild(msgDiv);
        chatArea.scrollTop = chatArea.scrollHeight;
    }
    
    let typingIndicator = null;
    function showTypingIndicator() {
        if(typingIndicator) return;
        typingIndicator = document.createElement('div');
        typingIndicator.className = 'ezcheats-msg ai ezcheats-typing';
        typingIndicator.innerHTML = '<span class="ezcheats-dot"></span><span class="ezcheats-dot"></span><span class="ezcheats-dot"></span>';
        chatArea.appendChild(typingIndicator);
        chatArea.scrollTop = chatArea.scrollHeight;
    }
    function removeTypingIndicator() {
        if(typingIndicator) {
            typingIndicator.remove();
            typingIndicator = null;
        }
    }

    chrome.storage.local.get(['ezcheats_chat'], function(result) {
        if (result.ezcheats_chat && result.ezcheats_chat.length > 1) {
            chatHistory = result.ezcheats_chat;
            chatHistory.forEach(msg => {
                if (msg.role !== 'system') {
                    let displayTxt = msg.content;
                    if (msg.role === 'user' && displayTxt.includes('--- PAGE CONTEXT ---')) {
                        displayTxt = displayTxt.split('--- PAGE CONTEXT ---')[0].trim();
                    }
                    if (displayTxt) addMessage(displayTxt, msg.role === 'user' ? 'user' : 'ai');
                }
            });
        } else {
            resetChat(false);
        }
    });

    function saveChat() {
        chrome.storage.local.set({ ezcheats_chat: chatHistory });
    }

    function resetChat(clearUI = true) {
        chatHistory = [{ role: 'system', content: SYSTEM_PROMPT }];
        saveChat();
        if (clearUI) {
            chatArea.innerHTML = '';
            addMessage('Chat reset. Welcome back.', 'ai');
        } else {
            addMessage('Welcome to EzCheats AI Chat. I am ready to assist.', 'ai');
        }
    }

    clearBtn.addEventListener('click', () => resetChat(true));

    function getContext() {
        let context = "\n\n--- PAGE CONTEXT ---\n";
        const fields = [];
        
        const elements = document.querySelectorAll('input:not([type="hidden"]):not([type="submit"]):not([type="button"]), textarea, select, [role="radio"], [role="checkbox"]');
        let index = 0;
        
        elements.forEach((el) => {
            if (el.closest('#ezcheats-container')) return; 
            
            const type = el.type || el.getAttribute('role');
            const isCheckable = type === 'radio' || type === 'checkbox';
            
            if (el.offsetWidth > 0 || el.offsetHeight > 0 || isCheckable) {
                if (el.tagName === 'INPUT' && el.closest('[role="radio"], [role="checkbox"]')) return;
                
                const id = el.id || el.name || 'ez_field_' + index++;
                el.setAttribute('data-ezcheats-id', id);
                
                let question = '';
                const listItem = el.closest('[role="listitem"]') || el.closest('.freebirdFormviewerViewItemsItemItem');
                if (listItem) {
                    const heading = listItem.querySelector('[role="heading"]') || listItem.querySelector('.freebirdFormviewerViewItemsItemItemTitle');
                    if (heading) question = heading.innerText;
                    else question = listItem.innerText.split('\n')[0];
                } else if (el.closest('fieldset')) {
                    const legend = el.closest('fieldset').querySelector('legend');
                    if (legend) question = legend.innerText;
                }
                
                let label = el.getAttribute('aria-label') || el.getAttribute('data-value') || '';
                if (!label && el.labels && el.labels.length > 0) label = el.labels[0].innerText;
                if (!label && el.placeholder) label = el.placeholder;
                
                if (!question) question = label;
                
                let fieldInfo = { 
                    id: id, 
                    type: type, 
                    question: question.trim().substring(0, 200)
                };
                
                if (isCheckable) {
                    let optText = el.getAttribute('data-value') || el.getAttribute('aria-label');
                    if (!optText && el.innerText) optText = el.innerText;
                    if (!optText && el.value && el.value !== 'on') optText = el.value;
                    if (!optText && el.closest('label')) optText = el.closest('label').innerText;
                    if (!optText) optText = label;
                    
                    fieldInfo.option = optText.trim().substring(0, 150);
                } else {
                    if (label && label !== question) {
                        fieldInfo.label = label.trim().substring(0, 150);
                    }
                }
                
                fields.push(fieldInfo);
            }
        });

        if (fields.length > 0) {
            context += "Form Fields on Page:\n" + JSON.stringify(fields) + "\n\n";
        }
        
        const container = document.getElementById('ezcheats-container');
        const oldOpacity = container ? container.style.opacity : '1';
        const oldPointer = container ? container.style.pointerEvents : 'auto';
        
        if (container) {
            container.style.opacity = '0';
            container.style.pointerEvents = 'none';
        }
        
        let text = document.body.innerText.substring(0, 2000);
        
        if (container) {
            container.style.opacity = oldOpacity;
            container.style.pointerEvents = oldPointer;
        }
        
        context += "Visible Text:\n" + text + "\n--------------------\n";
        return context;
    }

    function processAiResponse(replyText) {
        const jsonMatch = replyText.match(/```json\s*(\{[\s\S]*?\})\s*```/);
        let acted = false;
        
        if (jsonMatch) {
            try {
                const command = JSON.parse(jsonMatch[1]);
                if (command.fill) {
                    command.fill.forEach(f => {
                        const el = document.querySelector(`[data-ezcheats-id="${f.id}"]`);
                        if (el) {
                            const type = el.type || el.getAttribute('role');
                            if (type === 'radio' || type === 'checkbox') {
                                let shouldBeChecked = false;
                                if (f.value === true || String(f.value).toLowerCase() === "true" || f.value === "on") {
                                    shouldBeChecked = true;
                                } else if (typeof f.value === 'string' && f.value.trim() && (f.value === el.value || f.value === el.getAttribute('data-value') || (el.innerText && el.innerText.includes(f.value)))) {
                                    shouldBeChecked = true;
                                }
                                
                                let gWrapper = el.tagName === 'DIV' ? el : el.closest('[role="radio"], [role="checkbox"]');
                                if (!gWrapper && el.closest('label')) {
                                    gWrapper = el.closest('label').querySelector('[role="radio"], [role="checkbox"]');
                                }
                                
                                function hardClick(node) {
                                    ['mousedown', 'mouseup', 'click'].forEach(evt => {
                                        node.dispatchEvent(new MouseEvent(evt, { bubbles: true, cancelable: true, view: window }));
                                    });
                                }
                                
                                if (gWrapper) {
                                    const isChecked = gWrapper.getAttribute('aria-checked') === 'true';
                                    if (isChecked !== shouldBeChecked) hardClick(gWrapper);
                                } else {
                                    if (el.checked !== shouldBeChecked) {
                                        const label = el.closest('label');
                                        if (label) hardClick(label);
                                        else hardClick(el);
                                        
                                        if (el.checked !== shouldBeChecked) {
                                            el.checked = shouldBeChecked;
                                            el.dispatchEvent(new Event('change', { bubbles: true }));
                                        }
                                    }
                                }
                            } else {
                                el.value = f.value;
                                el.dispatchEvent(new Event('input', { bubbles: true }));
                                el.dispatchEvent(new Event('change', { bubbles: true }));
                            }
                            acted = true;
                        }
                    });
                }
            } catch (e) {
                console.error("Failed to parse form command");
            }
        }
    }

    function sendMessage() {
        const text = input.value.trim();
        if (!text) return;

        input.value = '';
        addMessage(text, 'user');
        showTypingIndicator();
        
        const context = getContext();
        const fullMessage = text + context;
        
        chatHistory.push({ role: 'user', content: fullMessage });
        saveChat();

        let apiMessages = chatHistory.map((msg, index) => {
            if (msg.role === 'user' && index < chatHistory.length - 1) {
                let cleanContent = msg.content.split('--- PAGE CONTEXT ---')[0].trim();
                return { role: msg.role, content: cleanContent };
            }
            return msg;
        });

        let port = chrome.runtime.connect({ name: 'chat_stream' });
        port.postMessage({ action: 'chat', messages: apiMessages });
        
        let aiMessageDiv = null;
        let fullResponse = '';
        
        port.onMessage.addListener((msg) => {
            if (msg.error) {
                removeTypingIndicator();
                addMessage("Error: " + msg.error, 'ai');
                chatHistory.pop();
                port.disconnect();
                return;
            }
            if (msg.chunk) {
                fullResponse += msg.chunk;
                
                removeTypingIndicator();
                if (!aiMessageDiv) {
                    aiMessageDiv = document.createElement('div');
                    aiMessageDiv.className = 'ezcheats-msg ai';
                    chatArea.appendChild(aiMessageDiv);
                }
                
                // Fallback in case model still outputs <think> despite prompt
                let displayRealText = fullResponse;
                if (displayRealText.includes('<think>')) {
                    let lastThinkOpen = displayRealText.lastIndexOf('<think>');
                    let lastThinkClose = displayRealText.indexOf('</think>', lastThinkOpen);
                    if (lastThinkClose === -1) {
                        displayRealText = displayRealText.substring(0, lastThinkOpen);
                    }
                }
                displayRealText = displayRealText.replace(/<think>[\s\S]*?<\/think>/g, '');
                
                if (displayRealText.includes('```json')) {
                    displayRealText = displayRealText.replace(/```json[\s\S]*/, '').trim();
                } else {
                    displayRealText = displayRealText.replace(/```json\s*\{[\s\S]*?\}\s*```/g, '').trim();
                }
                
                if (displayRealText) {
                    aiMessageDiv.innerHTML = parseMarkdown(displayRealText);
                } else {
                    aiMessageDiv.innerHTML = '<span style="opacity:0.5;font-style:italic;">Operating UI...</span>';
                }
                chatArea.scrollTop = chatArea.scrollHeight;
            }
            if (msg.done) {
                removeTypingIndicator();
                if (fullResponse.trim()) {
                    let finalRealText = fullResponse.replace(/<think>[\s\S]*?<\/think>/g, '').trim();
                    processAiResponse(finalRealText);
                    chatHistory.push({ role: 'assistant', content: fullResponse });
                    saveChat();
                } else {
                    addMessage("Error: Empty response.", 'ai');
                    chatHistory.pop();
                }
                port.disconnect();
            }
        });
    }

    sendBtn.addEventListener('click', sendMessage);
    input.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') sendMessage();
    });
})();
