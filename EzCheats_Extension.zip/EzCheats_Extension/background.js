
chrome.action.onClicked.addListener(async (tab) => {
    if (!tab.url || tab.url.startsWith('chrome://') || tab.url.startsWith('edge://') || tab.url.startsWith('about:')) {
        console.warn('EzCheats cannot run on browser internal pages.');
        return;
    }

    try {
        await chrome.tabs.sendMessage(tab.id, { action: 'toggleUI' });
    } catch (e) {
        console.log('EzCheats: Content script not found, injecting now...');
        try {
            await chrome.scripting.insertCSS({
                target: { tabId: tab.id },
                files: ['content.css']
            });
            await chrome.scripting.executeScript({
                target: { tabId: tab.id },
                files: ['content.js']
            });
            await chrome.tabs.sendMessage(tab.id, { action: 'toggleUI' });
        } catch (injectError) {
            console.error('EzCheats Injection Error:', injectError);
        }
    }
});

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'fetchKeys') {
        fetch('https://pastebin.com/raw/X96xQJLA')
            .then(r => r.text())
            .then(text => {
                const keys = text.trim().split('\n').map(k => k.trim()).filter(k => k.length > 10);
                sendResponse({ keys: keys });
            })
            .catch(err => {
                sendResponse({ error: 'Failed to fetch keys' });
            });
        return true;
    }

    if (request.action === 'chat') {
        chrome.storage.local.get(['ezcheats_active_key'], function(res) {
            let apiKey = res.ezcheats_active_key;
            if (!apiKey) {
                apiKey = atob('Z3NrX0Q5aTV3TzVGNVZyeWU2NlA1d2ZQV0dkeWIzRllBVGJnN09sN0tzM2tFWUM2U0ZaUlh4eks=');
            }
            
            fetch('https://api.groq.com/openai/v1/chat/completions', {
                method: 'POST',
                headers: {
                    'Authorization': 'Bearer ' + apiKey,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    model: 'groq/compound', 
                    messages: request.messages,
                    temperature: 0.1
                })
            })
            .then(apiRes => apiRes.json())
            .then(data => {
                if (data.choices && data.choices.length > 0) {
                    sendResponse({ reply: data.choices[0].message.content });
                } else if (data.error) {
                    sendResponse({ error: data.error.message });
                } else {
                    sendResponse({ error: 'Invalid API response' });
                }
            })
            .catch(err => {
                sendResponse({ error: err.toString() });
            });
        });
        return true; 
    }
});