// EzCheats - Background Service Worker

const _0xdefault = {
    _k: [
        "Z3NrX1dHUVhORFh4MUhoVDBXdjVPNjF", 
        "vV0dkeWIzRllzdWhQMUNka3h0bFhKaH", 
        "Jcnk4NnVwekxJ"                   
    ]
};

function getDefaultKey() {
    try {
        return atob(_0xdefault._k.join(''));
    } catch(e) {
        return "";
    }
}

chrome.action.onClicked.addListener(async (tab) => {
    if (!tab.url || tab.url.startsWith("chrome://") || tab.url.startsWith("edge://") || tab.url.startsWith("about:")) {
        console.warn("EzCheats cannot run on browser internal pages.");
        return;
    }

    try {
        await chrome.tabs.sendMessage(tab.id, { action: 'toggleUI' });
    } catch (e) {
        console.log("EzCheats: Content script not found, injecting now...");
        try {
            await chrome.scripting.insertCSS({
                target: { tabId: tab.id },
                files: ["content.css"]
            });
            await chrome.scripting.executeScript({
                target: { tabId: tab.id },
                files: ["content.js"]
            });
            await chrome.tabs.sendMessage(tab.id, { action: 'toggleUI' });
        } catch (injectError) {
            console.error("EzCheats Injection Error:", injectError);
        }
    }
});

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'chat') {
        chrome.storage.local.get(['ezcheats_active_key'], function(res) {
            let apiKey = res.ezcheats_active_key;
            if (!apiKey) {
                // Fallback to one of the defaults if not set yet
                apiKey = atob("Z3NrX0Q5aTV3TzVGNVZyeWU2NlA1d2ZQV0dkeWIzRllBVGJnN09sN0tzM2tFWUM2U0ZaUlh4eks=");
            }
            
            fetch('https://api.groq.com/openai/v1/chat/completions', {
                method: 'POST',
                headers: {
                    'Authorization': 'Bearer ' + apiKey,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    // Updated to current valid free-tier API string
                    model: 'groq/compound', 
                    messages: request.messages,
                    temperature: 0.1
                })
            })
            .then(apiRes => apiRes.json())
            .then(data => {
                if (data.choices && data.choices.length > 0) {
                    sendResponse({ reply: data.choices[0].message.content });
                } else if (data.error) {
                    sendResponse({ error: data.error.message });
                } else {
                    sendResponse({ error: "Invalid API response" });
                }
            })
            .catch(err => {
                sendResponse({ error: err.toString() });
            });
        });
        
        return true; 
    }
});
