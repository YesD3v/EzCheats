
chrome.action.onClicked.addListener(async (tab) => {
    if (!tab.url || tab.url.startsWith('chrome://') || tab.url.startsWith('edge://') || tab.url.startsWith('about:')) {
        console.warn('EzCheats cannot run on browser internal pages.');
        return;
    }

    try {
        await chrome.tabs.sendMessage(tab.id, { action: 'toggleUI' });
    } catch (e) {
        console.log('EzCheats: Content script not found, injecting now...');
        try {
            await chrome.scripting.insertCSS({
                target: { tabId: tab.id },
                files: ['content.css']
            });
            await chrome.scripting.executeScript({
                target: { tabId: tab.id },
                files: ['content.js']
            });
            await chrome.tabs.sendMessage(tab.id, { action: 'toggleUI' });
        } catch (injectError) {
            console.error('EzCheats Injection Error:', injectError);
        }
    }
});

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'fetchKeys') {
        fetch('https://pastebin.com/raw/X96xQJLA?t=' + Date.now(), { cache: 'no-store' })
            .then(r => r.text())
            .then(text => {
                const keys = text.trim().split('\n').map(k => k.trim()).filter(k => k.length > 10);
                if (keys.length === 0) {
                    sendResponse({ error: 'No API keys on Pastebin (Contact Owner)' });
                } else {
                    sendResponse({ keys: keys });
                }
            })
            .catch(err => {
                sendResponse({ error: 'Network Error: No Wi-Fi or request blocked' });
            });
        return true;
    }
});

chrome.runtime.onConnect.addListener(function(port) {
    if (port.name === 'chat_stream') {
        port.onMessage.addListener(function(msg) {
            if (msg.action === 'chat') {
                chrome.storage.local.get(['ezcheats_active_key'], function(res) {
                    let apiKey = res.ezcheats_active_key;
                    if (!apiKey) {
                        port.postMessage({ error: 'No active Node. Open settings and Shuffle Node Instance.' });
                        return;
                    }
                    
                    fetch('https://api.groq.com/openai/v1/chat/completions', {
                        method: 'POST',
                        headers: {
                            'Authorization': 'Bearer ' + apiKey,
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify({
                            model: 'groq/compound-mini', 
                            messages: msg.messages,
                            max_tokens: 1024,
                            temperature: 0.7,
                            stream: true
                        })
                    }).then(async (apiRes) => {
                        if (!apiRes.ok) {
                            const errData = await apiRes.json();
                            port.postMessage({ error: errData.error ? errData.error.message : 'API Error' });
                            return;
                        }
                        const reader = apiRes.body.getReader();
                        const decoder = new TextDecoder('utf-8');
                        let buffer = '';
                        while (true) {
                            const { done, value } = await reader.read();
                            if (done) break;
                            buffer += decoder.decode(value, { stream: true });
                            let lines = buffer.split('\n');
                            buffer = lines.pop(); 
                            for (let line of lines) {
                                line = line.trim();
                                if (line.startsWith('data: ')) {
                                    let dataStr = line.substring(6);
                                    if (dataStr === '[DONE]') continue;
                                    try {
                                        let data = JSON.parse(dataStr);
                                        if (data.error) {
                                            port.postMessage({ error: data.error.message || 'Stream Error' });
                                        } else if (data.choices && data.choices[0].delta && data.choices[0].delta.content) {
                                            port.postMessage({ chunk: data.choices[0].delta.content });
                                        }
                                    } catch (e) {}
                                }
                            }
                        }
                        port.postMessage({ done: true });
                    }).catch(err => {
                        port.postMessage({ error: err.toString() });
                    });
                });
            }
        });
    }
});
